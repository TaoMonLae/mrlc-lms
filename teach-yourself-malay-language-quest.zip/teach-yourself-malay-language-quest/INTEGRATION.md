# MRLC LMS Integration

Copy this package into the repository root, preserving paths.

## 1. Apply the repository patch

```bash
git apply PATCH_EXISTING_FILES.diff
```

If the repository already has the earlier Malay category and `ms-MY` voice changes, apply only the `package.json` and `languageQuest.ts` parts, or add the import and course registration manually.

## 2. Generate and validate

```bash
npm run generate:language-quest-teach-yourself-malay
npm run lint
npm run build
```

## 3. Restart the application

On startup, `ensureOfficialCourses()` creates the course if the code `MRLC-TEACH-YOURSELF-MALAY-V1` is not already present. Existing official courses are not overwritten automatically. To replace a previously seeded version, delete that course from the database in a controlled migration or change the course code.

## Voice

Malay is mapped to the browser locale `ms-MY`. The current Kokoro mapping in this repository has no Malay voice, so playback depends on an installed browser or operating-system Malay voice.

## Emoji-free display

The course uses an empty `imageEmoji` value and `null` for every option emoji. If a later editor normalizes an empty cover value to a globe, update the editor fallback before saving the official course.
